import { createApp } from 'vue';
import './style.css';
import App from './App.vue';
import router from './router';
import { createPinia } from 'pinia';

import './assets/scss/app.scss';

const pinia = createPinia();

export const app = createApp(App);

app.use(router).use(pinia).mount('#app');
