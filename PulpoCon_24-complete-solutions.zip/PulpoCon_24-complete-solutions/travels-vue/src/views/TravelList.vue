<script setup lang="ts">
import { computed } from 'vue';
import { TravelDetail } from '../components/TravelDetail';
import { useTravelStore } from '../store/Travel';
import { navigateTo } from '../helpers/routes';
import { URLS } from '../data/AppUrls';

const useTravel = useTravelStore();

const myTravels = computed(() => useTravel.travelList);

const onNewTravel = () => navigateTo(URLS.ADD);
</script>

<template>
  <div class="travel-list">
    <button class="travel-list__add" @click="onNewTravel">New Travel</button>

    <div class="travel-list__wrapper">
      <div
        class="travel-list__travel"
        v-for="travel in myTravels"
        :key="travel.id"
      >
        <TravelDetail :modelValue="travel" tag="viaje realizado"></TravelDetail>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import '../assets/scss/medias';
@import '../assets/scss/mixins';

.travel-list {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: var(--space-md);

  &__add {
    @include buttonStyle();
  }

  &__wrapper {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: var(--space-lg);
    grid-auto-rows: 1fr;

    margin-top: var(--space-lg);

    @include media(md) {
      grid-template-columns: repeat(2, 1fr);
    }

    @include media(sm) {
      grid-template-columns: repeat(1, 1fr);
    }
  }

  &__travel {
    display: contents;
  }
}
</style>
