<script setup lang="ts">
import { ITravel } from '../types/Travel';
import { defaultTravel, TravelTypeOptions } from '../data/Travel';
import { ref, onMounted, computed } from 'vue';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { useRoute } from 'vue-router';
import { useTravelStore } from '../store/Travel';
import { navigateTo } from '../helpers/routes';
import { URLS } from '../data/AppUrls';

const { errors, meta, defineField } = useForm({
  validationSchema: yup.object({
    currentType: yup.string().required(),
    currentDateString: yup.string().required(),
    currentCity: yup.string().min(3).required(),
  }),
});

const route = useRoute();

const useTravel = useTravelStore();

const currentTravel = ref<ITravel>();

const travelFromList = ref<ITravel>();

const [currentType, currentTypeAttrs] = defineField('currentType');

const [currentDateString, currentDateStringAttrs] =
  defineField('currentDateString');

const [currentCity, currentCityAttrs] = defineField('currentCity');

const hasErrors = computed(() => Object.keys(errors.value).length);

onMounted(() => {
  const currentId = Number(route.params.id as string);

  getTravel(currentId);
});

const getTravel = (currentId: number) => {
  travelFromList.value = structuredClone(defaultTravel);

  if (currentId > 0) {
    travelFromList.value =
      useTravel.getTravelById(currentId) ?? travelFromList.value;
  }
  currentTravel.value = Object.assign({}, travelFromList.value);

  initializeValues(currentTravel.value);
};

const initializeValues = (newTravel: ITravel) => {
  currentCity.value = newTravel.city;
  currentDateString.value = newTravel.date.toISOString().split('T')[0];
  currentType.value = newTravel.image
    ? newTravel.image.replace('src/assets/images/', '').replace('.webp', '')
    : '';
};

const getInputClass = (fieldName: string) => ({
  'travel-edit__row-field': true,
  'travel-edit__error':
    meta.value.touched && errors.value && errors.value[fieldName],
});

const onCancel = () => {
  currentTravel.value = Object.assign({}, travelFromList.value);
  initializeValues(currentTravel.value);
};

const onSave = () => {
  if (!errors.value.length && currentTravel.value) {
    updateData();
    navigateTo(URLS.LIST);
  }
};

const updateData = () => {
  if (currentTravel.value) {
    currentTravel.value.image = `src/assets/images/${currentType.value}.webp`;
    currentTravel.value.city = currentCity.value;
    currentTravel.value.date = new Date(currentDateString.value);

    currentTravel.value.id === 0
      ? useTravel.addTravel(currentTravel.value)
      : useTravel.editTravel(currentTravel.value);
  }
};
</script>

<template>
  <div class="travel-edit">
    <form v-if="currentTravel" class="travel-edit__form">
      <div class="travel-edit__row">
        <label for="type">Tipo de viaje*:</label>

        <select
          v-model="currentType"
          v-bind="currentTypeAttrs"
          :class="getInputClass('currentType')"
          name="select"
        >
          <option
            v-for="option in TravelTypeOptions"
            :key="option.id"
            :value="option.id"
          >
            {{ option.value }}
          </option>
        </select>
      </div>

      <div class="travel-edit__row">
        <label for="country">País:</label>

        <input
          v-model="currentTravel.country"
          class="travel-edit__row-field"
          type="text"
          id="country"
          name="country"
        />
      </div>

      <div class="travel-edit__row">
        <label for="city">Ciudad*:</label>

        <input
          v-model="currentCity"
          v-bind="currentCityAttrs"
          :class="getInputClass('currentCity')"
          type="text"
          id="city"
          name="city"
        />
      </div>

      <div class="travel-edit__row">
        <label for="date">Fecha*:</label>

        <input
          v-model="currentDateString"
          v-bind="currentDateStringAttrs"
          :class="getInputClass('currentDateString')"
          type="date"
          id="date"
        />
      </div>

      <div class="travel-edit__row">
        <label for="description">Descripción:</label>

        <textarea
          v-model="currentTravel.description"
          class="travel-edit__row-field"
          type="text"
          id="description"
          name="description"
          rows="20"
        ></textarea>
      </div>
    </form>

    <div class="travel-edit__actions">
      <button
        class="travel-edit__actions-secondary-btn"
        type="reset"
        @click="onCancel"
      >
        Cancelar
      </button>

      <button
        class="travel-edit__actions-btn"
        :disabled="!meta.valid"
        @click="onSave"
      >
        Guardar
      </button>
    </div>

    <span v-if="hasErrors" class="travel-edit__error">
      Completa los campos obligatorios
    </span>
  </div>
</template>

<style lang="scss" scoped>
@import '../assets/scss/mixins';

.travel-edit {
  width: 30rem;
  margin: var(--space-xl) auto;

  display: flex;
  flex-direction: column;
  gap: var(--space-xl);

  &__form {
    display: flex;
    flex-direction: column;
    gap: var(--space-xl);
  }

  &__row {
    display: flex;
    justify-content: space-between;
  }

  &__row-field {
    min-width: 20rem;
  }

  &__actions {
    display: flex;
    justify-content: flex-end;
    gap: var(--space-md);
  }

  &__error {
    color: red;
    border-color: red;
  }

  &__actions-btn {
    @include buttonStyle();

    &:disabled {
      background-color: var(--disabled-color);
      border-color: var(--disabled-color);
      color: white;
    }
  }

  &__actions-secondary-btn {
    @include secondaryButton();
  }
}
</style>
