<script setup lang="ts"></script>

<template>
  <div class="not-found">Sorry, page not found</div>
</template>

<style lang="scss" scoped>
.not-found {
  display: flex;
  justify-content: center;
  margin-top: var(--space-xl);
}
</style>
