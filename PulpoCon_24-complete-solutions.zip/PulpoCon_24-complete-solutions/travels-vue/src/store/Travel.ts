import { defineStore } from 'pinia';
import { myTravels } from '../data/Travel';
import { ITravel } from '../types/Travel';
import { computed, ref } from 'vue';

export const useTravelStore = defineStore('travel', () => {
  const _travelList = ref(structuredClone(myTravels));

  const travelList = computed(() => _travelList.value);

  const addTravel = (currentTravel: ITravel) => {
    const maxTravelIndex = Math.max.apply(
      null,
      _travelList.value.map((travel) => travel.id)
    );

    currentTravel.id = maxTravelIndex + 1;

    _travelList.value.push(currentTravel);
  };

  const editTravel = (currentTravel: ITravel) => {
    const travelToEditIndex = _travelList.value.findIndex(
      (travel) => travel.id === currentTravel.id
    );
    _travelList.value[travelToEditIndex] = currentTravel;
  };

  const getTravelById = (travelId: number): ITravel | undefined =>
    _travelList.value.find((travel) => travel.id === travelId);

  return {
    travelList,
    addTravel,
    editTravel,
    getTravelById,
  };
});
