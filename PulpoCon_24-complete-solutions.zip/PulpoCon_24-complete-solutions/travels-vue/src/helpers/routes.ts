import router from '../router';

export const navigateTo = (url: string) => {
  router.push(url);
};
