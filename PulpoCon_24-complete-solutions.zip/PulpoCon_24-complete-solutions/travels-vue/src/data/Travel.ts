import { ComboboxOption } from '../types/General';
import { ITravel } from '../types/Travel';

export const myTravels: ITravel[] = [
  {
    id: 1,
    country: 'EEUU',
    description: `Viaje sorpresa a Nueva York en Enero para descubrir la ciudad. En el
        viaje no nos nevó y pudimos visitar varios museos: el de Ciencias
        Naturales, el MOMA, el MET. También pudimos ver la Estatua de La
        Libertad e ir de compras.`,
    city: 'Nueva York',
    date: new Date('2020-01-21'),
    image: 'src/assets/images/city.webp',
  },
  {
    id: 2,
    country: 'República Checa',
    description: `Viaje de aniversario a Praga, a pesar del COVID. Pudimos disfrutar de la ciudad,
    a pesar de no estar preparada para el turismo y nos apañamos con Google Translator`,
    city: 'Praga',
    date: new Date('2021-08-10'),
    image: 'src/assets/images/city.webp',
  },
];

export const defaultTravel: ITravel = {
  id: 0,
  country: '',
  description: '',
  city: '',
  date: new Date(),
  image: '',
};

export const TravelTypeOptions: ComboboxOption[] = [
  {
    id: 'city',
    value: 'Cultural',
  },
  {
    id: 'nature',
    value: 'Naturaleza salvaje',
  },
  {
    id: 'beach',
    value: 'Desconexión relax',
  },
];
