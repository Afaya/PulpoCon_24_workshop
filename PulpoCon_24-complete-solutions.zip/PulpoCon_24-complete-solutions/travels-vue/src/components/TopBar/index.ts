import TopBar from './TopBar.vue';

export { TopBar };
