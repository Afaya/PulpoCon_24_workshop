import TravelDetail from './TravelDetail.vue';

export { TravelDetail };
