<script setup lang="ts">
import { ITravel } from '../../types/Travel';
import { computed, withDefaults, defineProps, defineModel } from 'vue';
import router from '../../router';
import { URLS } from '../../data/AppUrls';

interface TravelDetail {
  tag?: string;
}

withDefaults(defineProps<TravelDetail>(), {
  tag: 'Soy una tag',
});

const currentTravel = defineModel<ITravel>({ required: true });

const currentTravelDate = computed(
  () => currentTravel.value.date.toLocaleString('es-ES').split(',')[0]
);

const onEdit = () => router.push(`${URLS.EDIT}${currentTravel.value.id}`);
</script>

<template>
  <div class="travel-detail">
    <div class="travel-detail__actions">
      <button class="travel-detail__actions-edit" @click="onEdit">Edit</button>
    </div>

    <img
      alt="imagen de viaje"
      class="travel-detail__image"
      :src="currentTravel.image"
    />

    <div class="travel-detail__text-wrapper">
      <span class="travel-detail__main-text">Country:</span>
      <span>{{ currentTravel.country }}</span>
    </div>

    <div class="travel-detail__text-wrapper">
      <span class="travel-detail__main-text">City:</span>
      <span>{{ currentTravel.city }}</span>
    </div>

    <div class="travel-detail__text-wrapper">
      <span class="travel-detail__main-text">Date:</span>
      <span>{{ currentTravelDate }}</span>
    </div>

    <div
      class="travel-detail__text-wrapper travel-detail__text-wrapper--description"
    >
      <span class="travel-detail__main-text">Description:</span>
      <span>{{ currentTravel.description }}</span>
    </div>

    <div class="travel-detail__text-wrapper">
      <span class="travel-detail__chip">{{ tag }}</span>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import 'src/assets/scss/mixins';

.travel-detail {
  border: var(--border);
  padding: var(--space-md);
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
  height: 95%;

  &__actions {
    display: flex;
    justify-content: flex-end;
    padding: 0 var(--space-sm);
  }

  &__actions-edit {
    @include buttonStyle();
  }

  &__image {
    width: 98%;
  }

  &__text-wrapper {
    display: flex;
    gap: var(--space-sm);

    &--description {
      flex-direction: column;
    }
  }

  &__main-text {
    font-weight: var(--text-bold);
  }

  &__chip {
    background-color: var(--yellow);
    border-radius: 2em;
    padding: var(--space-sm);
  }
}
</style>
