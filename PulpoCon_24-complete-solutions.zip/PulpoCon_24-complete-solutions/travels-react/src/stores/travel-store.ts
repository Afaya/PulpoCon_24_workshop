import { myTravels } from '@/data/Travel';
import { ITravel } from '@/types/Travel';
import { createStore } from 'zustand/vanilla';

export type TravelState = {
  travelList: ITravel[];
};

export type TravelActions = {
  addTravel: (currentTravel: ITravel) => void;
};

export type TravelStore = TravelState & TravelActions;

export const defaultInitState: TravelState = {
  travelList: [],
};

export const initTravelStore = (): TravelState => {
  console.log('init travel store');
  return { travelList: structuredClone(myTravels) };
};

export const createTravelStore = (
  initState: TravelState = defaultInitState
) => {
  return createStore<TravelStore>()((set) => ({
    ...initState,
    addTravel: (currentTravel: ITravel) => {
      set((state) => ({ travelList: [...state.travelList, currentTravel] }));
    },
  }));
};
