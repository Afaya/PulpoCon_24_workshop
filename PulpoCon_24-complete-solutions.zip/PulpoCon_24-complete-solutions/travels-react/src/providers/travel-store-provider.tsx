'use client'

import { type ReactNode, createContext, useRef, useContext } from 'react'
import { useStore } from 'zustand'

import {
  type TravelStore,
  createTravelStore,
  initTravelStore,
} from '@/stores/travel-store'

export type TravelStoreApi = ReturnType<typeof createTravelStore>

export const TravelStoreContext = createContext<TravelStoreApi | undefined>(
  undefined,
)

export interface TravelStoreProviderProps {
  children: ReactNode
}

export const TravelStoreProvider = ({
  children,
}: TravelStoreProviderProps) => {
  const storeRef = useRef<TravelStoreApi>()
  if (!storeRef.current) {
    storeRef.current = createTravelStore(initTravelStore())
  }

  return (
    <TravelStoreContext.Provider value={storeRef.current}>
      {children}
    </TravelStoreContext.Provider>
  )
}

export const useTravelStore = <T,>(
  selector: (store: TravelStore) => T,
): T => {
  const travelStoreContext = useContext(TravelStoreContext)

  if (!travelStoreContext) {
    throw new Error(`useTravelStore must be used within TravelStoreProvider`)
  }

  return useStore(travelStoreContext, selector)
}
