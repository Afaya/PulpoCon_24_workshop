import { ReactNode } from 'react';
import Topbar from './topbar';

interface LayoutProps {
  children: ReactNode
};

const RootLayout = ({children}: LayoutProps) => {
  return (
    <>
      <Topbar />
      <main>{children}</main>
    </>
  );
};

export default RootLayout;
