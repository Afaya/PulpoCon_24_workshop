import styles from "./TravelEdit.module.scss";
import { defaultTravel, TravelTypeOptions } from "../../data/Travel";
import { useForm, SubmitHandler } from "react-hook-form"
import { ITravel } from "@/types/Travel";
import { useRouter } from "next/router";
import { useTravelStore } from '@/providers/travel-store-provider';
import { URLS } from "@/data/AppUrls";

interface ITravelEdit extends ITravel {
  currentType: string;
  dateAsString: string;
};

export default function Travels() {
  const NATURE_OPTION = 'nature';

  const router = useRouter();

  const { travelList, addTravel } = useTravelStore(
    (state) => state,
  );

  const { setValue, register, handleSubmit, formState: { errors } } = useForm<ITravelEdit>({
    defaultValues: {...structuredClone(defaultTravel), currentType: NATURE_OPTION}
  });

  const currentId = Number(router.query.id as string);

  const currentTravel = travelList.find(travel => travel.id === currentId);

  const fillForm = () => {
    const initialData = currentId === 0 ? structuredClone(defaultTravel) : currentTravel;

    if(initialData){
      const currentType = initialData.image ? initialData.image.replace('/', '').replace('.webp', '') : NATURE_OPTION;
      const currentDateAsString = initialData?.date.toISOString().split('T')[0];
      setValue("id", initialData.id);
      setValue("city", initialData.city);
      setValue("country", initialData.country);
      setValue("dateAsString", currentDateAsString);
      setValue("description", initialData?.description);
      setValue("currentType", currentType);
    } 
  }

  if(currentId > 0 && currentTravel){
    fillForm();
  };

  const hasErrors = Object.keys(errors).length;

  const onSave: SubmitHandler<ITravelEdit> = (data: ITravelEdit) => {
    if(!hasErrors){
      const isEdition =  data.id !== 0;

      const currentId = !isEdition ? Math.max.apply(
        null,
        travelList.map((travel) => travel.id)
      ) +1 : data.id;
  
      const newTravel: ITravel = {
        id: currentId,
        description: data.description,
        city: data.city,
        country: data.country,
        date: new Date(data.dateAsString),
        image: `/${data.currentType}.webp`
      }

      isEdition ? editTravel(newTravel, currentId): addTravel(newTravel);

      router.push(URLS.LIST);
    }
  }

  const editTravel = (newTravel: ITravel, currentId: Number) => {
    const currentListIndex = travelList.findIndex(travel => travel.id === currentId);
    travelList[currentListIndex] = newTravel;
  }

  const onCancel = () => fillForm();

  
  return (
    <>
      <main className={styles.main}>
        <form className={styles.travelEdit}>
          <div className={styles.travelEdit__row}>
            <label htmlFor="type">Tipo de viaje:</label>

            <select className={errors.currentType ? styles.travelEdit__rowFieldError : styles.travelEdit__rowField} {...register("currentType", { required: true})}>
              {TravelTypeOptions.map(option => 
                  <option key={option.id} value={option.id}>{option.value}</option>
              )}
            </select>
          </div>

          <div className={styles.travelEdit__row}>
            <label htmlFor="country">País:</label>

            <input
              className={styles.travelEdit__rowField}
              type="text"
              id="country"
              {...register("country")}
            />
          </div>

          <div className={styles.travelEdit__row}>
            <label htmlFor="city">Ciudad:</label>

            <input className={errors.city ? styles.travelEdit__rowFieldError : styles.travelEdit__rowField} type="text" id="city" {...register("city", { required: true, minLength: 3 })} />
          </div>

          <div className={styles.travelEdit__row}>
            <label htmlFor="date">Fecha:</label>

            <input className={errors.date ? styles.travelEdit__rowFieldError : styles.travelEdit__rowField} type="date" id="date" {...register("dateAsString", { required: true})} />
          </div>

          <div className={styles.travelEdit__row}>
            <label htmlFor="description">Descripción:</label>

            <textarea
              className={styles.travelEdit__rowField}
              id="description"
              rows={20}
              {...register("description")}
            ></textarea>
          </div>

          <label className={styles.travelEdit__error}>{hasErrors ? 'Completa los campos obligatorios': ''}</label>

         
        </form>

        <div className={styles.travelEdit__actions}>
            <button className={styles.travelEdit__actionsSecondaryBtn} onClick={onCancel}>
              Cancelar
            </button>
            <button className={styles.travelEdit__actionsBtn} onClick={handleSubmit(onSave)}>Guardar</button>
          </div>
      </main>
    </>
  );
}

