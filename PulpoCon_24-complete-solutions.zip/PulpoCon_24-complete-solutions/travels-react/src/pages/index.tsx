import styles from "@/styles/Home.module.scss";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { URLS } from "../data/AppUrls";


export default function Home() {
  
const router = useRouter();

const goTo = (pageUrl: string) => router.push(pageUrl);
  return (
    <>
    
      <main className={styles.home}>

      <Image
                src="/Pulpi-React.png"
                alt="Logo de React encima del pulpo de la pulpoConf"
                width="200"
                height="300"
              />

        <q className={styles.home__quote}>La vida, o es una aventura o no es nada</q>

        <p className={styles.home__subquote}>Hellen Keller</p>

        <div className={styles.home__actions}>
          <button className={styles.home__actionsSecondaryBtn} onClick={() => goTo(URLS.ADD)}>Nuevo viaje</button>

          <button className={styles.home__actionsBtn} onClick={() => goTo(URLS.LIST)}>Ver viajes</button>
        </div>
      </main>
    </>
  );
}
