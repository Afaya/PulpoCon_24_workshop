import { TravelDetail } from "@/components/travelDetail/index";
import styles from "./Travels.module.scss";
import { useTravelStore } from '@/providers/travel-store-provider';
import { useRouter } from "next/navigation";
import { URLS } from "@/data/AppUrls";

export default function Travels() {
  const { travelList } = useTravelStore(
    (state) => state,
  )

  const router = useRouter();

  const addTravel = () => router.push(URLS.ADD);

  return (
    <>
      <main className={styles.travelList}>
        <button className={styles.travelList__add} onClick={() => addTravel()}>New Travel</button>

        <div className={styles.travelList__wrapper}>
          {travelList.map(travel => 
              <div key={travel.id} className={styles.travelList__travel}>
                
                <TravelDetail currentTravel={travel}></TravelDetail>
              </div>
          )}
          
        </div>
      </main>
    </>
  );
}
