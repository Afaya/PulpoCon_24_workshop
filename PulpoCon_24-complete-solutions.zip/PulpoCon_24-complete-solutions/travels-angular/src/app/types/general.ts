export interface ComboboxOption {
    id: string;
    value: string;
}