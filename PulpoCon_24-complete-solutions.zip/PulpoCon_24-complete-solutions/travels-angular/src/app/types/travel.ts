export interface ITravel {
    id: number;
    country?: string;
    description?: string;
    city: string;
    date: Date;
    image?: string;
}
