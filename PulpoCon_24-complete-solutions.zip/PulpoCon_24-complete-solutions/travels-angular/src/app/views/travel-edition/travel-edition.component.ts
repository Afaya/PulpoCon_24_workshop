import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ITravel } from '../../types/travel';
import { defaultTravel, TravelTypeOptions } from '../../data/travel';
import { ComboboxOption } from '../../types/general';
import { NgClass } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { StoreService } from '../../store/store.service';
import { RouterHelperService } from '../../helpers/router-helper.service';
import { URLS } from '../../data/urls';

@Component({
  selector: 'app-travel-edition',
  standalone: true,
  imports: [ReactiveFormsModule, NgClass],
  templateUrl: './travel-edition.component.html',
  styleUrl: './travel-edition.component.scss'
})
export class TravelEditionComponent {
  travelTypeOptions: ComboboxOption[] = TravelTypeOptions;
  currentTravel?: ITravel;
  travelType = new FormControl("", Validators.required);
  travelForm?: FormGroup;

  constructor(private route: ActivatedRoute, private storeService: StoreService, private routerHelper: RouterHelperService) {
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const id = +params['id'];

      if (id === 0) {
        this.currentTravel = defaultTravel;
      } else {
        this.currentTravel = this.storeService.getTravelById(id) ?? defaultTravel;
        const currentTravelType = this.currentTravel.image ? this.currentTravel.image.replace('images/', '').replace('.webp', '') : "";
        this.travelType.setValue(currentTravelType);
      }

      this.travelForm = new FormGroup(
        {
          id: new FormControl(this.currentTravel.id),
          country: new FormControl(this.currentTravel.country),
          description: new FormControl(this.currentTravel.description),
          city: new FormControl(this.currentTravel.city, [Validators.required, Validators.minLength(3)]),
          date: new FormControl(this.currentTravel.date.toISOString().split('T')[0], Validators.required),
          image: new FormControl(this.currentTravel.image),
        }
      );
    });
  }

  onSave(): void {
    if (this.travelForm && this.travelForm.value) {
      const newUpdateTravel = this.travelForm.value as ITravel;

      newUpdateTravel.image = `images/${this.travelType.value}.webp`;
      newUpdateTravel.date = new Date(newUpdateTravel.date);

      if (newUpdateTravel.id === 0) {
        this.storeService.addTravelList(newUpdateTravel);
      } else if (this.currentTravel) {
        this.currentTravel.id = newUpdateTravel.id;
        this.currentTravel.country = newUpdateTravel.country;
        this.currentTravel.description = newUpdateTravel.description;
        this.currentTravel.city = newUpdateTravel.city;
        this.currentTravel.date = newUpdateTravel.date;
        this.currentTravel.image = newUpdateTravel.image;
      }

      this.routerHelper.goTo(URLS.LIST);
    }
  }
}
