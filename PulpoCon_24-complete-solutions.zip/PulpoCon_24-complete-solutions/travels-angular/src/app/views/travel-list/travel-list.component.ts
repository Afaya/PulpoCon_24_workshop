import { Component, OnInit } from '@angular/core';
import { TravelDetailComponent } from '../../components/travel-detail/travel-detail.component';
import { ITravel } from '../../types/travel';
import { StoreService } from '../../store/store.service';
import { RouterHelperService } from '../../helpers/router-helper.service';
import { URLS } from '../../data/urls';

@Component({
  selector: 'app-travel-list',
  standalone: true,
  imports: [TravelDetailComponent],
  templateUrl: './travel-list.component.html',
  styleUrl: './travel-list.component.scss'
})
export class TravelListComponent implements OnInit {
  urlsEnum = URLS;
  travelList: ITravel[] = [];

  constructor(private storeService: StoreService, protected routerHelper: RouterHelperService) {
  }

  ngOnInit(): void {
    this.storeService.getTravelList().subscribe({
      next: (response: ITravel[]) => {
        if (response) {
          this.travelList = response;
        }
      }, error: (error: any) => {
        this.travelList = [];
      }
    });
  }
}
