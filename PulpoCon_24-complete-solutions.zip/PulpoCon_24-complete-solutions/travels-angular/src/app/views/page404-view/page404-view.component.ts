import { Component } from '@angular/core';

@Component({
  selector: 'app-page404-view',
  standalone: true,
  imports: [],
  templateUrl: './page404-view.component.html',
  styleUrl: './page404-view.component.scss'
})
export class Page404ViewComponent {

}
