import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TopBarComponent } from './components/top-bar/top-bar.component';
import { StoreService } from './store/store.service';
import { myTravels } from './data/travel';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, TopBarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  title = '';

  constructor(private storeService: StoreService) {
  }

  ngOnInit(): void {
    this.storeService.setTravelList(myTravels);
  }
}
