export enum URLS {
    LIST = "/travels",
    EDIT = "/travel-edit/",
    ADD = "/travel-edit/0",
    HOME = "/",
}
