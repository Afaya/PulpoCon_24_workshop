
import { Component, Input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ITravel } from '../../types/travel';
import { URLS } from '../../data/urls';
import { RouterHelperService } from '../../helpers/router-helper.service';

@Component({
  selector: 'app-travel-detail',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './travel-detail.component.html',
  styleUrl: './travel-detail.component.scss'
})
export class TravelDetailComponent {
  @Input() currentTravel!: ITravel;
  urlsEnum = URLS;

  constructor(protected routerHelper: RouterHelperService) { }
}